#!/bin/sh
. ./n.sh
clean_repo
#fined
gitpush
#instruction