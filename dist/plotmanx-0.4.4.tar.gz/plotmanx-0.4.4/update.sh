#!/bin/sh
. ./n.sh

clean_repo
#fined
#instruction

gitpush